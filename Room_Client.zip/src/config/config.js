// export const url = "https://server.roomlelo.in"
  export const url = "http://localhost:7000"

export const MAP_API_KEY = process.env.REACT_APP_MAP_API_KEY 